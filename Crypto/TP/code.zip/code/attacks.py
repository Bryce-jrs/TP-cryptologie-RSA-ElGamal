import random
import sys
from math import sqrt
from common import *
from rsa import *

####################
# Q20
####################
def smallN_attack(e,N,c):
    return 0

####################
# Q21
####################
def commonFactor_attack(e1,N1,c1,e2,N2):   
    return 0

####################
# Q22
####################
def resteChinois(e_123,n_1,c_1,n_2,c_2,n_3,c_3):
    return 0
    
####################
# Q23
####################
# todo
